package com.thetestingacademy;

public class TestNG04 {

}
